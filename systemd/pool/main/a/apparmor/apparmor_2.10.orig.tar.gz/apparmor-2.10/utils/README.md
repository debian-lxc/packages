Known Bugs:
Will allow multiple letters in the () due to translation/unicode issues with regexing the key.
User input will probably bug out in a different locale.
